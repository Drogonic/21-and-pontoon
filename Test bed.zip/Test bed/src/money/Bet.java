package money;

import java.util.ArrayList;

public class Bet {
        public String name;
        public int score;




        public Bet(String name) {
            score = 500;
            this.name = name;

        }

        public int getScore() {
            return score;
        }

        public void setScore(int score) {
            this.score = score;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public void scorePrint(int handsPlayed, boolean endGame) {
            if (getScore() <= 1000) {
                System.out.println("Highway Robbery, thrown out by pitboss/nScore:/t:" + getScore());
            } else if (getScore() == 0 && endGame) {
                System.out.println("House always wins/nBetter luck next time");
            } else if (getScore() != 0 && endGame) {
                System.out.println("Good Haul/nScore is:/t" + getScore());
            }
        }
    }



