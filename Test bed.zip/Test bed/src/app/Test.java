package app;

import money.Bet;

import java.util.*;


public class Test {
    public static Scanner playerChoice = new Scanner(System.in);
    public static Random rndGen = new Random();
    public static Bet playerBet = new Bet("Jerry");

    public static void main(String[] args) {
        System.out.println("Score:" + playerBet.getScore());
        blackJack(bets());
    }

    //------------------------------------------------------------------------
    public static void blackJack(int bet) {
        System.out.println("\n");
        boolean blackJack = true;
        boolean insurance = false;
        int insuranceTaken=0;
        ArrayList<Integer> dealerHand = new ArrayList<>(2);
        ArrayList<Integer> playerHand = new ArrayList<>(2);


        for (int x = 0; x <= 1; x++) {
            dealerHand.add(cardValue());

        }
        if (dealerHand.get(0) == 11 || dealerHand.get(1) == 11) {
            System.out.println("Insurance?, dealer showing ACE.y/n");
            String playerResponse = playerChoice.nextLine().toLowerCase();
            if (playerResponse.charAt(0) == 'y') {
                insurance = true;
                insuranceTaken=bet/2;
            }
        } else {
            System.out.println("Dealer:" + dealerHand.get(0));
        }

        for(int x=0;x<=1;x++) {
            playerHand.add(cardValue());
            if(handValue(playerHand)==21){
                System.out.println("Player:"+(playerHand.get(0)+playerHand.get(1)));
                winner(playerHand,dealerHand,blackJack,bet);
                System.out.println("Replay?");
                String playerResponse=playerChoice.nextLine().toLowerCase();
                replay(playerResponse);
            }else if(handValue(dealerHand)==21){
                System.out.println("Player:"+(playerHand.get(0)+playerHand.get(1)));
                System.out.println("Dealer had black jack:"+(dealerHand.get(0)+dealerHand.get(1)));
                winner(playerHand,dealerHand,blackJack,bet);
                System.out.println("Replay?");
                String playerResponse=playerChoice.nextLine().toLowerCase();
                replay(playerResponse);
            }
        }
        System.out.println("Player:"+(playerHand.get(0)+playerHand.get(1)));

        System.out.println("Hit or Stand");
        String playerResponse=playerChoice.nextLine().toLowerCase();

        while(playerResponse.equals("hit")){
            playerHand.add(cardValue());
            if (handValue(playerHand)>21){
                System.out.println("Player:"+handValue(playerHand));
                winner(playerHand,dealerHand,!blackJack,bet);
            }
            System.out.println("Player:"+handValue(playerHand));
            System.out.println("Hit or Stand");
            playerResponse=playerChoice.nextLine().toLowerCase();
        }

        while(handValue(dealerHand)<17){
            dealerHand.add(cardValue());
        }
        System.out.println("Dealer:"+handValue(dealerHand));

        winner(playerHand,dealerHand,!blackJack,bet);



    }
    public static void winner(ArrayList<Integer> player,ArrayList<Integer> dealer,boolean blackJack,int scoreBet) {
        int playerScore=playerBet.getScore();
        if(blackJack&&handValue(player)==21) {
            System.out.println("Black Jack: Player");
            playerScore+=scoreBet*2.5;
        }else if(blackJack&&handValue(dealer)==21){
            System.out.println("Black Jack: Dealer. You LOSE");
            playerScore-=scoreBet;
        }else if(handValue(player)>=22) {
            System.out.println("BUSTED WITH A HAND OF: " + player);
            playerScore-=scoreBet;
        }else if (handValue(dealer) >= 22) {
            System.out.printf("Dealer has busted with %d. WINNER\n", handValue(dealer));
            playerScore+=scoreBet*2;
        } else if (handValue(dealer) > handValue(player)) {
            System.out.println("YOU LOST\t" + "PLAYER:"+handValue(player) + "\t" + "DEALER:" + handValue(dealer));
            playerScore-=scoreBet;
        } else if (handValue(dealer) == handValue(player)) {
            System.out.println(" There was a PUSH");
            playerScore+=scoreBet;
        } else {
            System.out.println("You WIN");
            playerScore+=scoreBet*2;
        }
        playerBet.setScore(playerScore);
        System.out.println("Score:"+playerBet.getScore());
        System.out.println("Replay? y/n");
        String replaychoice=playerChoice.nextLine().toLowerCase();
        replay(replaychoice);
    }
    public static void replay(String response){

        if(response.charAt(0)=='y'){
            blackJack(bets());
        }
    }

    public static int handValue(ArrayList<Integer> list){
        int value=0;
        for(Integer numbers:list){
            value+=numbers;
        }
        return value;
    }

    public static int cardValue(){
        int value=rndGen.nextInt(11-1)+1;
        if(value==1) {
            value = 11;
        }
        return value;
    }

public static int bets(){
    int scoreBet=0;
    int counter=0;
    while(scoreBet<5) {
        if(counter!=0){
            System.out.println("Last bet too low");
        }
        try {
            System.out.println("5 score buy in. Would you like to go minimum or risk more?(Type 5 or enter custom whole amount)");
            scoreBet = playerChoice.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("That is not a valid bet, try with no decimals. Try Again");
        }
        if (scoreBet == 0) {
            System.out.println("5 score buy in. Would you like to go minimum or risk more?");
            playerChoice.nextLine();
            scoreBet = playerChoice.nextInt();
        }
        counter++;
    }
    playerChoice.nextLine();
    return scoreBet;
}
public static int bets(boolean insurance,int insuranceAmount){
    int playerScore=playerBet.getScore();
    playerScore+=insuranceAmount;
}



}//end Controller

